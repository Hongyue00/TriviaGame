﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TriviaGame_2._0
{
    class Player
    {
        public string Name;
        public int score;

        public Player(string name, int score)
        {
            Name = name ;
            score = 0;
        }
    }
}
