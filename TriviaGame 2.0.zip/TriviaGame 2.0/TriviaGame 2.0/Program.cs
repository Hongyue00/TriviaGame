﻿using System;
// Lacie 2021 Mar 15
// Austin Derrickson helped me with external file accessing, and Karen helped me fix some programming issues.
namespace TriviaGame_2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Game triviagame = new Game();
            triviagame.showquestions();
        }
    }
}
