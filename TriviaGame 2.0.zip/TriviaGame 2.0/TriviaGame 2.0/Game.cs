﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;

namespace TriviaGame_2._0
{
    class Game
    {
        List<string> questions;
        List<string> multiplechoices;
       
        List<string> correctanswers;
        public List<int> tracking = new List<int>();
        System.Random rand = new System.Random();
        Player Player1 = new Player("Player1", 0);
        public void showquestions()
        {
           
            questions = File.ReadAllLines(@"C:\Users\玥\Desktop\TriviaGame 2.0\TriviaGame 2.0\triviaquestions.txt").ToList<string>();
            multiplechoices = File.ReadAllLines(@"C:\Users\玥\Desktop\TriviaGame 2.0\TriviaGame 2.0\multiplechoices.txt").ToList<string>();
            correctanswers= File.ReadAllLines(@"C:\Users\玥\Desktop\TriviaGame 2.0\TriviaGame 2.0\correctanswer.txt").ToList<string>();
            for(int q=0; q<questions.Count;q++)
            {
                int order = randomlize();
                Console.WriteLine(questions[order]);
               
                    Console.WriteLine(multiplechoices[order]);
                check(order);
                stop();
            }
           
        }
        public void check(int order)
        {
           
                Console.WriteLine("What is your answer?");
            string input = Console.ReadLine();
            input = input.ToUpper();
            bool validinput = true;
            while (validinput)
            {
                if (input == correctanswers[order])
                {
                    Console.WriteLine("That's correct!");

                    Player1.score++;
                }
                else if(input!=correctanswers[order]&&( input == "A" || input != "B" || input != "C" || input != "D"))
                {
                    Console.WriteLine("Sorry, but that is incorrect.");
                }

               else
                {
                    Console.WriteLine("Please enter a valid answer");
                    validinput = false;
                   
                }
                Console.WriteLine($"Your score is {Player1.score}");
                Console.WriteLine("Press enter for next question.");
                Console.ReadKey();
                Console.Clear();
                break;
            }

        }
        public int randomlize()
        {
            int index = rand.Next(0, questions.Count);
            if (tracking.Contains(index))
            {
                randomlize();
            }
            else
            {
                tracking.Add(index);
                return (index);
               
            }
            return index;

        }

        public void stop()
        {
                Console.WriteLine("Press N to exist");
            string playerinput = Console.ReadLine();
            playerinput = playerinput.ToUpper();
           
                 
            
                if (playerinput == "N")
                {
                    Console.WriteLine($"Your score is {Player1.score} ");
                    Environment.Exit(0);
                }
               else
                {
                    return;
                }
               


                
            
        }
    }
}
